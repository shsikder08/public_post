<?php $__env->startSection('title'); ?>
    New Video
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
            	<?php echo Form::open(['route' => 'admin.videos.store','method' => 'POST','files'=>'true']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', null,['class'=> 'form-control','placeholder'=>'Type a title','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('title','Wich type of video you want to upload?'); ?>

                        <br>
                        <div class="btn btn-danger youtube">Youtube Video</div>
                        <div class="btn btn-success normal">Normal Video</div>
                    </div>
                    <div class="form-group videolink">
                        <?php echo Form::label('video_link','Copy and Paste YouTube video ID'); ?>


                        
                        <?php echo Form::text('video_link', null,['class'=> 'form-control','placeholder'=>'Type a Video ID']); ?>

                       <h4>Copy and Paste from YouTube ID : </h4>
                        <img src="<?php echo e(asset('img/youtube.jpg')); ?>" alt="">
                    </div>
                    <div class="form-group videonormal">
                        <?php echo Form::label('videos','Upload your video'); ?>


                        <?php echo Form::file('videos[]', array('multiple'=>true)); ?>

                        <br>
                        <div class="alert alert-warning">
                            <p>* Videos must be 10mb or less.</p>
                        </div>
                    </div>


                    <div class="form-group">
                        <?php echo Form::label('category_id','Category'); ?>

                        <?php echo Form::select('category_id', $categories,null,['class'=> 'form-control select-category','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('content','Content'); ?>

                        <?php echo Form::textarea('content', null,['class' => 'textarea-content form-control','required']); ?>

                    </div>
                    <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
                    <div class="form-group">
                        <?php echo Form::label('featured','Mark as Featured'); ?>                        
                        <?php echo e(Form::checkbox('featured', 'true')); ?>                         
                    </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <?php echo Form::select('tags[]', $tags,null,['class'=> 'form-control select-tag chosen-select','multiple']); ?>

                    </div>

            		<div class="form-group">
            			<?php echo Form::submit('Add Video',['class'=>'btn btn-primary']); ?>

            		</div>

            	<?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('.videonormal').hide();
        $('.videolink').hide();

        $('.youtube').on('click',function(e){
            $('.videolink').fadeIn();
            $('.videonormal').hide();
        });
        $('.normal').on('click',function(e){
            $('.videonormal').fadeIn();
            $('.videolink').hide();
        });
        $(".select-tag").chosen({
            placeholder_text_multiple: "Select your tags"
        });
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>