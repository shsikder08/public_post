
<?php $__env->startSection('title'); ?>
    Edit Photo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">
  
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(['route' => ['admin.photos.update',$photo->id],'method' => 'PUT','files'=>'true']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', $photo->title,['class'=> 'form-control','placeholder'=>'Type a title','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('category_id','Category'); ?>

                        <?php echo Form::select('category_id', $categories,$photo->category->id,['class'=> 'form-control select-category','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('photo_link','Photo Link'); ?>

                        <?php echo Form::text('photo_link', $photo->photo_link,['class'=> 'form-control','placeholder'=>'Type photo download url','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('content','Content'); ?>

                        <?php echo Form::textarea('content', $photo->content,['class' => 'textarea-content','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('featured','Mark as Featured'); ?>

                        <?php if($photo->featured == 'true'): ?>
                        <?php echo e(Form::checkbox('featured', 'true',true)); ?>

                        <?php else: ?>
                        <?php echo e(Form::checkbox('featured', 'true',false)); ?>

                        <?php endif; ?>      
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <?php echo Form::select('tags[]', $tags,$myTags,['class'=> 'form-control select-tag','multiple','required']); ?>

                    </div>
                    
                    <div class="form-group">
                        <?php echo Form::label('images','Images'); ?>

                        <?php echo Form::file('images[]', array('multiple'=>true)); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::submit('Edit Photo',['class'=>'btn btn-primary']); ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
            
            <!-- Photo Images -->
            <div class="col-md-6 type" data-type="photos">
                <h1>Images</h1>
                <hr>
                <?php if(count($photo->images) > 0): ?>  
                    <?php
                        $i=0;
                    ?>
                    <?php foreach($photo->images as $image): ?>
                    <div class="col-xs-12">
                        <img src="<?php echo e(asset('img/photos/thumbs').'/thumb_'.$image->name, '$photo->title'); ?>" alt="The Public Photo <?php echo e($photo->title); ?>">
                        <p class="col-xs-12" style="padding-left:0px; margin-top:10px;">
                            <a href="#" class="btn-delete btn btn-danger"  data-imgid="<?php echo e($image->id); ?>"><i class="fa fa-trash fa-2x"></i></a>
                        </p>
                    </div>
                    <hr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Not images found. Please add a new image.</p>  
                <?php endif; ?>      
            </div>
        </div>
        <!-- /.row -->
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $(".select-tag").chosen({
            placeholder_text_multiple: "Select your tags"
        });
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });

        $('.textarea-content').trumbowyg({
            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>