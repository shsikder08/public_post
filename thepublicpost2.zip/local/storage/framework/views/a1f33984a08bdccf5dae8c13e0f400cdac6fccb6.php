
<?php $__env->startSection('title'); ?>
    New Video
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
            	<?php echo Form::open(['route' => 'admin.videos.store','method' => 'POST','files'=>'true']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', null,['class'=> 'form-control','placeholder'=>'Type a title','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('video_link','Video ID'); ?>


                        
                        <?php echo Form::text('video_link', null,['class'=> 'form-control','placeholder'=>'Type a Video ID','required']); ?>

                       <h4>Copy and Paste from YouTube ID : </h4>
                        <img src="<?php echo e(asset('img/youtube.jpg')); ?>" alt="">
                    </div>


                    <div class="form-group">
                        <?php echo Form::label('category_id','Category'); ?>

                        <?php echo Form::select('category_id', $categories,null,['class'=> 'form-control select-category','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('content','Content'); ?>

                        <?php echo Form::textarea('content', null,['class' => 'textarea-content form-control','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('featured','Mark as Featured'); ?>                        
                        <?php echo e(Form::checkbox('featured', 'true')); ?>                         
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <?php echo Form::select('tags[]', $tags,null,['class'=> 'form-control select-tag chosen-select','multiple','required']); ?>

                    </div>

            		<div class="form-group">
            			<?php echo Form::submit('Add Video',['class'=>'btn btn-primary']); ?>

            		</div>

            	<?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(".select-tag").chosen({
            placeholder_text_multiple: "Select your tags"
        });
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });

        $('.textarea-content').trumbowyg({
            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>