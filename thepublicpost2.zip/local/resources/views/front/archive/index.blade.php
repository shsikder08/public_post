@extends('layouts.front')
@section('css')
<link rel="stylesheet" href="{{asset('dist/css/home-logged.css')}}">
@endsection
@section('title','Archive')
@section('content')


@endsection