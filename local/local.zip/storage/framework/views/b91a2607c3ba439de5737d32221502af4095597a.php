<?php $__env->startSection('title','All Ebooks'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.ebooks.create')); ?>" class="btn btn-info"> Create New Ebook</a>
            	<?php echo Form::open(['route'=>'admin.ebooks.index','method'=>'GET','class'=>'navbar-form pull-right']); ?>

            		<div class="input-group">
            			<?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'Search Ebook','aria-describedby'=>'search']); ?>

            			<span class="input-group-addon" id="search">
            				<span class="glyphicon glyphicon-search" aria-hidden="true" ></span>
            			</span>
            		</div>
            	<?php echo Form::close(); ?>

            	<hr>

				<table class="tablesorter table" id="myTable">
					<thead>
						<th>ID <span class="pull-right fa fa-sort"></span></th>
						<th>Title <span class="pull-right fa fa-sort"></span> </th>
						<th>Categories <span class="pull-right fa fa-sort"></span></th>
						<th>Ebook Link <span class="pull-right fa fa-sort"></span></th>		
						<th>User <span class="pull-right fa fa-sort"></span></th>						
						<th>Status <span class="pull-right fa fa-sort"></span></th>
						<th>Views <span class="pull-right fa fa-sort"></span></th>
						<th>Action</th>
					</thead>

					<tbody>
						<?php foreach($ebooks as $ebook): ?>
							<tr>
								<td><?php echo e($ebook->id); ?></td>
								<td><?php echo e($ebook->title); ?></td>
								<td><?php echo e($ebook->category->name); ?></td>
								<td><?php echo e($ebook->ebook_link); ?></td>
								<td><?php echo e($ebook->user->name); ?></td>
								<td><?php echo e($ebook->status); ?></td>
								<td><?php echo e($ebook->views); ?></td>
								<td>
									<?php if($ebook->status == 'approved' && Auth::user()->type=='admin'): ?>
									<a href="#" onclick="return confirm('This ebooks is already approved.');" class="btn btn-success" disabled="disabled">Approve</a>
									<?php elseif(Auth::user()->type == 'admin'): ?>
										<a href="<?php echo e(route('admin.ebooks.approve',$ebook->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-success">Approve</a>
									<?php endif; ?>
									<?php if($ebook->status == 'suspended' && Auth::user()->type=='admin'): ?>
									<a href="<?php echo e(route('admin.ebooks.suspend',$ebook->id)); ?>" onclick="return confirm('This ebooks is already suspended.');" disabled="disabled" class="btn btn-primary">Suspend</a>
									<?php elseif(Auth::user()->type == 'admin'): ?>									
									<a href="<?php echo e(route('admin.ebooks.suspend',$ebook->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-primary">Suspend</a>
									<?php endif; ?>
									<a href="<?php echo e(route('admin.ebooks.edit',$ebook->id)); ?>" class="btn btn-warning">Edit</a>
								   <a href="<?php echo e(route('admin.ebooks.destroy',$ebook->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-danger">Delete</a> </td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="text-center">
					<?php echo $ebooks->render(); ?>

				</div>
				
            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>