<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
All photos | The Public Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div class="container">
        <div class="row myid" data-photo="<?php echo e($photo->id); ?>">

            <!-- Blog Post Content Column -->
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 col-lg-offset-0 col-mds-offset-0 col-xs-offset-0 post">
                <!-- Blog Post -->

                <!-- Banner_ad -->
                    <?php if($topHorizontalBanner != ''): ?>
                    <img class="img-responsive center-block banner-ad2" width="728" height="90" src="<?php echo e(asset('img/advs/adv_'.$topHorizontalBanner)); ?>" alt="banner_ad" style="margin-top:20px">
                    <?php else: ?>
                    <div class="center-block banner-ad2"  style="margin-top:20px">
                        <?php echo e($topHorizontalBannerScript); ?>                        
                    </div>
                    <?php endif; ?>

                <div class="col-lg-12 nopadding m-b30">
                    <a href="#" class="astyl13">
                        <h3>সমস্ত ফটো</h3>
                    </a>

                </div>
                    <div class="col-lg-9 col-md-12 view2" style="padding:0">
                        <img src="<?php echo e(asset('img/photos/slider_'.$photo->images()->first()->name)); ?>" alt="">
                        <div class="mask2">
                            <p><a href="#"><?php echo e(strip_tags(str_limit($photo->content, 100))); ?></a></p>
                        </div>
                    </div>
                    <div class="ad-up col-lg-3 col-md-3">
                        <?php if($rightSingle != ''): ?>
                            <img class="center-block img-responsive m-tb50" src="<?php echo e(asset('img/advs/adv_'.$rightSingle)); ?>">
                        <?php else: ?>
                            <div class="center-block m-tb50">
                                <?php echo e($rightSingleScript); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 nopadding m-b20">
                        <a href="#" class="astyl4">
                            <h3><?php echo e($photo->title); ?></h3>
                        </a>
                        <a href="#" class="pull-left m-r5">
                        <?php if($photo->user()->first()->profile_image && $photo->user()->first()->facebook_id == null && $photo->user()->first()->twitter_id == null): ?>
                        <img src="<?php echo e(asset('img/users/profile/profile_'.$photo->user()->first()->profile_image)); ?>" class="img-responsive" width="20px" height="20px" alt=""></a>
                        <?php elseif($photo->user()->first()->facebook_id != null || $photo->user()->first()->twitter_id != null): ?>
                        <img src="<?php echo e($photo->user()->first()->profile_image); ?>" class="img-responsive" width="20px" height="20px" alt=""></a>
                        <?php endif; ?>
                       	 <?php echo e($photo->user()->first()->name); ?> 
                        <span class="glyphicon glyphicon-time m-lr10"><?php echo e($photo->created_at); ?></span><span class="icon icon-eye"> <?php echo e($photo->views()->count()); ?> মতামত</span><br><br>
                        <a class="btn btn-primary" href="<?php echo e(url('photos/'.$photo->id)); ?>">আরো দেখুন <span class="glyphicon glyphicon-chevron-right"></span></a>
                    </div>
                    <div class="ad-bottom col-lg-12">
                        <img class="center-block img-responsive" src="https://placeholdit.imgix.net/~text?txtsize=19&txt=150%C3%97300&w=150&h=300" alt="">
                    </div>
                    <div class="col-lg-12 nopadding h60">
                        <hr class="divstyl3 nopadding">
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-3 hidden-xs categorias nopadding">
                    <ul class="list-group">
                    <?php foreach($sidebars as $sidebar): ?>
                        <li class="list-group-item"><a href="#" class="astyl4 fw-b">- <?php echo e($sidebar->category()->first()->name); ?></a></li>
                    <?php endforeach; ?>
                    </ul>
                </div>
                <div class="col-xs-12 visible-xs categories nopadding m-b20">
                    <button class="btn btn-primary dropdown-toggle w100porcent bc-0061d8" type="button" id="dropdownenu1" data-toggle="dropdown" aria-extended="true">
                        Categories
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu divstyl4" role="menu" aria-labellebdy="dropdownmenu1">
                    <?php foreach($sidebars as $sidebar): ?>
                        <li class="list-group-item"><a href="#" class="astyl4 fw-b">- <?php echo e($sidebar->category()->first()->name); ?></a></li>
                    <?php endforeach; ?>
                    </ul>
                </div>
                <div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 portafolio-content">
                    <!-- Projects Row -->
        <div class="row portafolios">
        <?php foreach($related_photos as $photo): ?>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 portafolio-item">

                <a href="<?php echo e(url('photos/'.$photo->id)); ?>" class="td-n">
                    <img class="img-responsive" src="<?php echo e(asset('img/photos/slider_'.$photo->images()->first()->name)); ?>" alt="<?php echo e($photo->title); ?>">
                    <p class="astyl16"><?php echo e($photo->title); ?></p>
                </a>
            </div>
        <?php endforeach; ?>
        </div>
            <div class="row text-center">
            <div class="col-lg-12">
            <?php echo e($related_photos->render()); ?>

            </div>
        </div>
                </div>
            </div>
            <!-- Blog Sidebar Widgets Column -->
            <?php echo $__env->make('layouts.partials.front.rightsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        </div>
        <!-- /.row -->
    <!-- /.container -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('front-js'); ?>
<script>
$(".captcha-error").hide();
$(".captcha-correct").hide();
$('#submit').prop('disabled', true);
    $("#resolve").click(function(e){
    e.preventDefault();     
        var resultInput = $('.result').val();
        var resultOriginal = $('.nums').data('result');
        //check if the result is okey
        if(resultInput == resultOriginal){
            $('#submit').prop('disabled', false);
            $(".captcha-correct").show();
            $(".captcha-error").hide();
            $('#submit').unbind('click');
        }else{
            $('#submit').prop('disabled', true);
            $(".captcha-error").show();
            $(".captcha-correct").hide();
        }
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>