<?php $__env->startSection('title','My Advertisements'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.advs.create')); ?>" class="btn btn-info"> Create New Adv</a>
            	<?php echo Form::open(['route'=>'admin.advs.index','method'=>'GET','class'=>'navbar-form pull-right']); ?>

            		<div class="input-group">
            			<?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'Search Photoadv','aria-describedby'=>'search']); ?>

            			<span class="input-group-addon" id="search">
            				<span class="glyphicon glyphicon-search" aria-hidden="true" ></span>
            			</span>
            		</div>
            	<?php echo Form::close(); ?>

            	<hr>

				<table class="tablesorter table" id="myTable" data-count="<?php echo e(count($advs)); ?>"> <!-- Get count to validate 3 post only and don't break the front end -->
					<thead>
						<th>ID <span class="pull-right fa fa-sort"></span></th>
						<th>Section <span class="pull-right fa fa-sort"></span>
						<th>Action</th>
					</thead>
					<tbody>
						<?php foreach($advs as $adv): ?>
							<tr>
								<td><?php echo e($adv->id); ?></td>
								<td><?php echo e($adv->section); ?></td>
								<td>
									<?php if($adv->status == 'approved' && Auth::user()->type=='admin' || Auth::user()->type == 'editor'): ?>
									<a href="#" onclick="return confirm('This advs is already approved.');" class="approve-disable btn btn-success" disabled="disabled">Approve</a>
									<?php elseif(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
									<a href="<?php echo e(route('admin.advs.approve',$adv->id)); ?>"  class="approve btn btn-success">Approve</a>
									<?php endif; ?>
									<?php if($adv->status == 'suspended' && Auth::user()->type=='admin' || Auth::user()->type == 'editor'): ?>
									<a href="<?php echo e(route('admin.advs.suspend',$adv->id)); ?>"  disabled="disabled" class="suspend-disable btn btn-primary">Suspend</a>
									<?php elseif(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
									<?php if(Auth::user()->type != 'subscriptor'): ?>					
									<a href="<?php echo e(route('admin.advs.suspend',$adv->id)); ?>" class="suspend btn btn-primary">Suspend</a>
									<?php endif; ?>
									<?php endif; ?>
									<a href="<?php echo e(route('admin.advs.edit',$adv->id)); ?>" class="edit btn btn-warning">Edit</a>
									<?php if(Auth::user()->type == 'admin'): ?>
								    <a href="<?php echo e(route('admin.advs.destroy',$adv->id)); ?>"  class="delete btn btn-danger">Delete</a>
								    <?php endif; ?> 
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="text-center">
					<?php echo $advs->render(); ?>

				</div>
				
            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>